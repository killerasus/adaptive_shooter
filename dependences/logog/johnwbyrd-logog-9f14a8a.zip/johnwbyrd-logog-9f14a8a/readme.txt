See http://www.logog.org or http://johnwbyrd.github.com/logog/ for more information and complete documentation.

logog is a portable C++ library to facilitate logging of real-time events in performance-oriented applications, such as games. It is especially appropriate for projects that have constrained memory and constrained CPU requirements.

General support and discussion is available at http://groups.google.com/group/logog .  Development support and discussion is available at http://groups.google.com/group/logog-devel .

This project can be built using CMake, available from http://www.cmake.org .

Local documentation can be generated with doxygen, available from  http://www.doxygen.org .

The license agreement for logog is viewable at http://johnwbyrd.github.com/logog/license.html .
