/* 
 * \file socket.cpp
 */

#include "logog.hpp"

namespace logog {
	bool sb_AvoidLinkError4221_socket_cpp = false;
}

